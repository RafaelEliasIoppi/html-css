

function slide1(){
    document.getElementById("banner").src="imagens/logo/inter.png"
    setTimeout("slide2()",1000)
}

function slide2(){
    document.getElementById("banner").src="imagens/logo/Juventude.png"
    setTimeout("slide3()",1000)
}

function slide3(){
    document.getElementById("banner").src="imagens/logo/Ypiranga.png"
    setTimeout("slide4()",1000)
}

function slide4(){
    document.getElementById("banner").src="imagens/logo/CAXIAS.png"
    setTimeout("slide1()",1000)
    
}
//var Pic =""

/*function displayImage (pic){

    let divLocation = document.getElementById("imgDiv")
    let imgElement = document.createElement("img")
    imgElement.src = pic
    divLocation.append(imgElement)
}
Pic = "imagens/logo/inter.png"
displayImage(Pic);
*/


  